package ExamenPooT4;

public class ChapaException extends Exception{
    public ChapaException (String m){
        super();
    }
}
